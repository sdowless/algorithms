//: Playground - noun: a place where people can play

import UIKit
//
////Basic Algorithms

//for i in 1...30 {
//    if i % 5 == 0  && i % 3 == 0{
//        print("FizzBuzz")
//    } else if i % 3 == 0 {
//        print("Fizz")
//    } else if i % 5 == 0 {
//        print("Buzz")
//    } else {
//        print(i)
//    }
//}

//Binary/Linear Search

let numArray = [1,27,9,2,3,4,5,6,7]
numArray.sorted(by: <)


func linearSearch(value: Int, array: [Int]) -> Bool {
    
    for num in array {
        if value == array[num] {
            return true
        } else {
            return false
        }
    }
    return false
}

func binarySearch(value: Int, array: [Int]) -> Bool {
    
    let array = array.sorted(by: <)
    
    var leftIndex = 0
    var rightIndex = array.count - 1
    
    while leftIndex <= rightIndex {
        
        let middleIndex = (leftIndex + rightIndex) / 2
        let middleValue = array[middleIndex]
        
        if middleValue == value {
            return true
        }
        
        if value < middleValue {
            rightIndex = middleIndex - 1
        }
        
        if value > middleValue {
            leftIndex = middleIndex + 1
        }
    }
    return false
}

print(binarySearch(value: 27, array: numArray))

//// Factorial algorithm //
//
//func computeFactorial(n: Int) -> Int {
//    
//    var product = 1
//    
//    for i in 1...n {
//        product *= i
//    }
//    return product
//}
//
//computeFactorial(n: 5)
//
//let nameArray = ["Stephan", "Brandon", "Amanda", "Stephan"]
//
//func mostCommonNameInArray(array: [String]) -> String{
//    
//    var nameDictionary = [String: Int]()
//    
//    for name in array {
//        
//        //  Upon first encounter of name, the if statement does not execute, because there is no associalted value for the key that is being set. When the name is encountered for again, the if statement executes. Use if let here becuase the value for the key has to be set in order for this to work. the nameCount is then set to whatever the value is at the time. the loop ends when every element has been checked in the array.
//        
//        if let nameCount = nameDictionary[name]{
//            nameDictionary[name] = nameCount + 1
//        } else {
//            nameDictionary[name] = 1
//        }
//    }
//    
//    var commonName = ""
//    
//    for key in nameDictionary.keys {
//        if commonName == "" {
//            commonName = key
//        } else {
//            let count = nameDictionary[key]
//            if count! > nameDictionary[commonName]! {
//                commonName = key
//            }
//        }
//    }
//    return commonName
//}
//
//print(mostCommonNameInArray(array: nameArray))


// Reverse every other word in string //

//let sampleSentence = "Lets start today with an interesting challenge"
//
//func reverseWordsInSentence(sentence: String) -> String {
//    
//    let allWords = sampleSentence.components(separatedBy: " ")
//    var newSentence = ""
//    
//    for i in 0..<allWords.count{
//        let word = allWords[i]
//        if newSentence != "" {
//            newSentence += " "
//        }
//        
//        if i % 2 == 1 {
//            let reverseWord = String(word.characters.reversed())
//            newSentence += reverseWord
//        } else {
//            newSentence += word
//        }
//    }
//    
//    return newSentence
//}
//
//print(reverseWordsInSentence(sentence: sampleSentence))

//
//var nameAgeDictionary = [String: Int]()
//
//func nameToAge(arrayName: [String], arrayAge: [Int]) {
//    
//    for (age, name) in arrayName.enumerated() {
//        nameAgeDictionary[name] = arrayAge[age]
//    }
//
//    for key in nameAgeDictionary.keys {
//        print("\(key): \(nameAgeDictionary[key]!)")
//    }
//}
//
//nameToAge(arrayName: nameArray, arrayAge: ageArray)






