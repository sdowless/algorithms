// NEED: Min, Max, Height


class BinarySearchTree {
    
    var value: Int
    var left: BinarySearchTree?
    var right: BinarySearchTree?
    var parent: BinarySearchTree?
    
    var isRight: Bool {
        return value > parent!.value
    }
    
    var isLeft: Bool {
        return value < parent!.value
    }

    var isLeaf: Bool {
        return self.right == nil && self.left == nil
    }
    
    var hasRight: Bool {
        return right != nil
    }
    
    var hasLeft: Bool {
        return left != nil
    }
    
    var hasOneChild: Bool {
        return hasRight || hasLeft
    }
    
    var hasTwoChildren: Bool {
        return hasRight && hasLeft
    }
    
    init(value: Int) {
        self.value = value
    }
    
    func insert(value: Int) {
        insert(value: value, parent: self)
    }
    
    func insert(value: Int, parent: BinarySearchTree) {
        
        if value < self.value {
            
            if let left = left {
                left.insert(value: value)
            } else {
                left = BinarySearchTree(value: value)
                left?.parent = parent
            }
        } else {
            if let right = right {
                right.insert(value: value)
            } else {
                right = BinarySearchTree(value: value)
                right?.parent = self
            }
        }
    }
    
    func removeLeaf(tree: BinarySearchTree) {
        
        if tree.isLeft {
            tree.parent?.left = nil
        } else {
            tree.parent?.right = nil
        }
    }
    
    func removeNodeWithOneChild(tree: BinarySearchTree) {
        
        if tree.isLeft{
            if tree.hasRight {
                tree.parent?.left = tree.right
            } else {
                tree.parent?.left = tree.left
            }
        }
        
        if tree.isRight{
            if tree.hasRight {
                tree.parent?.right = tree.right
            } else {
                tree.parent?.right = tree.left
            }
        }
    }
    
    func removeNodeWithTwoChildren(tree: BinarySearchTree) {
        
        if tree.isLeft {
            tree.parent?.left = tree.right
            tree.right?.left = tree.left
        } else {
            tree.parent?.right = tree.left
        }
    }
    
    func remove(value: Int) {
        
        if let found = search(value: value) {
            
            if found.isLeaf {
                removeLeaf(tree: found)
            }
            
            if found.hasOneChild {
                removeNodeWithOneChild(tree: found)
            }
            
            if found.hasTwoChildren {
                removeNodeWithTwoChildren(tree: found)
            }
        }
        
    }
    
    func search(value: Int) -> BinarySearchTree? {
        
        if value == self.value {
            return self
        }
        
        if value < self.value {
            return (left?.search(value: value))!
        }
        
        if value > self.value {
           return (right?.search(value: value))!
        }
        
        return nil
    }
    
    func minimum() -> Int {
        var node = self

        while node.left != nil {
            node = node.left!
        }
        return node.value
    }
    
    func maximum() -> Int {
        var node = self
        
        while node.right != nil {
            node = node.right!
        }
        return node.value
    }
    
    func height() -> Int {
        
        if isLeaf {
            return 0
        } else {
            return 1 + max(left?.height() ?? 0, right?.height() ?? 0)
        }
    }
    
    public func depth() -> Int {
        var node = self
        var edges = 0
        while let parent = node.parent {
            node = parent
            edges += 1
        }
        return edges
    }
    
    func inOrderTraversal() -> [Int] {
        
        var resultArray = [Int]()
        
        if let left = left {
            resultArray += left.inOrderTraversal()
        }
        
        resultArray.append(self.value)
        
        if let right = right {
            resultArray += right.inOrderTraversal()
        }
        
        return resultArray
    }
    
    func preOrderTraversal() -> [Int] {
        var resultArray = [self.value]
        
        if let left = left {
            resultArray += left.preOrderTraversal()
        }
        
        if let right = right {
            resultArray += right.preOrderTraversal()
        }
        
        return resultArray
    }

    func postOrderTraversal() -> [Int] {
        
        var resultArray = [Int]()
        
        if let left = left {
            resultArray += left.postOrderTraversal()
        }
        
        if let right = right {
            resultArray += right.postOrderTraversal()
        }
        
        resultArray.append(value)
        
        return resultArray
    }
}

extension BinarySearchTree: CustomStringConvertible {
    var description: String {
        var text = ""
        
        if let left = left {
            text += "(\(left.description)) < - "
        }
        
        text += "\(value)"
        
        if let right = right {
            text += " - > (\(right.description))"
        }
        return text
    }
}


let tree = BinarySearchTree(value: 6)

tree.insert(value: 2)
tree.insert(value: 5)
tree.insert(value: 1)
tree.insert(value: 10)
tree.insert(value: 9)


if let node9 = tree.search(value: 9) {
    print(node9.depth())   // returns 2
}



print(tree)








































//
//import UIKit
//
//class BinarySearchTree {
//    
//    var value: Int
//    var left: BinarySearchTree?
//    var right: BinarySearchTree?
//    var parent: BinarySearchTree?
//    
//    var hasLeft: Bool {
//        return left != nil
//    }
//    
//    var hasRight: Bool {
//        return right != nil
//    }
//    
//    var isRight: Bool {
//        return self.value > parent!.value
//    }
//    
//    var isLeft: Bool {
//        return self.value < parent!.value
//    }
//    
//    var isLeaf: Bool {
//        return left == nil && right == nil
//    }
//    
//    var hasOneChild: Bool {
//        return left != nil || right != nil
//    }
//    
//    var hasTwoChildren: Bool {
//        return left != nil && right != nil
//    }
//    
//    init(value: Int) {
//        self.value = value
//    }
//    
//    public func height() -> Int {
//        if isLeaf {
//            return 0
//        } else {
//            return 1 + max(left?.height() ?? 0, right?.height() ?? 0)
//        }
//    }
//    
//    func insert(value: Int) {
//        insert(value: value, parent: self)
//    }
//    
//    private func insert(value: Int, parent: BinarySearchTree) {
//        
//        if value < self.value {
//            if let left = left {
//                left.insert(value: value)
//                left.parent = parent
//            } else {
//                left = BinarySearchTree(value: value)
//                left?.parent = parent
//            }
//        } else {
//            if let right = right {
//                right.insert(value: value)
//                right.parent = parent
//            } else {
//                right = BinarySearchTree(value: value)
//                right?.parent = parent
//            }
//        }
//    }
//    
//    func search(value: Int) -> BinarySearchTree? {
//        
//        if value == self.value {
//            return self
//        }
//        
//        if value < self.value {
//            if let found = left?.search(value: value) {
//                return found
//            }
//        }
//        
//        if value > self.value {
//            if let found = right?.search(value: value) {
//                return found
//            }
//        }
//        return nil
//    }
//    
//    func removeLeafNode(node: BinarySearchTree){
//       
//        if node.value < (node.parent?.value)! {
//            node.parent?.left = nil
//        } else {
//            node.parent?.right = nil
//        }
//    }
//    
//    func removeNodeWithOneChild(node: BinarySearchTree) {
//        
//        if node.hasLeft && node.isRight {
//            node.parent?.right = node.left
//        } else if node.hasLeft && node.isLeft {
//            node.parent?.left = node.left
//        }
//        
//        if node.hasRight && node.isLeft{
//            node.parent?.left = node.right
//        } else if node.hasRight && node.isRight {
//            node.parent?.right = node.right
//        }
//    }
//    
//    func removeNodeWithTwoChildren(node: BinarySearchTree) {
//        
//        if node.isLeft {
//            node.parent?.left = node.right
//            node.right?.left = node.left
//        }
//        
//        if node.isRight {
//            node.parent?.right = node.left
//            node.left?.right = node.right
//        }
//    }
//    
//    func remove(value: Int) {
//        
//        if let found = search(value: value) {
//            
//            if found.isLeaf {
//                removeLeafNode(node: found)
//            }
//            
//            if found.hasOneChild {
//                removeNodeWithOneChild(node: found)
//            }
//            
//            if found.hasTwoChildren {
//                removeNodeWithTwoChildren(node: found)
//            }
//        }
//    }
//    
//    func preOrderTraversal() -> [Int] {
//        
//        var valueArray = [value]
//        
//        if left != nil {
//            valueArray += (left?.preOrderTraversal())!
//        }
//        
//        if right != nil {
//            valueArray += (right?.preOrderTraversal())!
//        }
//        return valueArray
//    }
//    
//    func inOrderTraversal() -> [Int] {
//        
//        var valueArray = [Int]()
//        
//        if left != nil {
//            valueArray += (left?.inOrderTraversal())!
//        }
//        
//        valueArray.append(value)
//        
//        if right != nil {
//            valueArray += (right?.inOrderTraversal())!
//        }
//        
//        return valueArray
//    }
//    
//    func postOrderTraversal() -> [Int] {
//        
//        var valueArray = [Int]()
//        
//        if (self.left?.isLeaf)! {
//            valueArray.append((left?.value)!)
//        } else {
//           valueArray += (left?.postOrderTraversal())!
//        }
//        
//        if (self.right?.isLeaf)! {
//            valueArray.append((right?.value)!)
//        } else {
//            valueArray += (right?.postOrderTraversal())!
//        }
//        
//        valueArray.append(value)
//        
//        return valueArray
//    }
//
//public func map(@noescape formula: T -> T) -> [T] {
//    var a = [T]()
//    if let left = left { a += left.map(formula) }
//    a.append(formula(value))
//    if let right = right { a += right.map(formula) }
//    return a
//}
//
//
//
//}
//
//extension BinarySearchTree: CustomStringConvertible {
//    var description: String {
//        var text = ""
//        
//        if let left = left {
//            text += "(\(left.description)) < - "
//        }
//        
//        text += "\(value)"
//        
//        if let right = right {
//            text += " - > (\(right.description))"
//        }
//        
//        return text
//    }
//}
//
//let tree = BinarySearchTree(value: 7)
//
//tree.insert(value: 5)
//tree.insert(value: 10)
//tree.insert(value: 4)
//tree.insert(value: 6)
//
//tree.insert(value: 9)
//tree.insert(value: 11)
//
//print(tree.preOrderTraversal())
//print(tree.inOrderTraversal())
//print(tree.postOrderTraversal())
//
//
